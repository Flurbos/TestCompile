// Copyright (c) 2013 The Bitcoin Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef FLURBO_NOUI_H
#define FLURBO_NOUI_H

extern void noui_connect();

#endif // FLURBO_NOUI_H
