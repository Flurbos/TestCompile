<TS language="ro" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Click dreapta pentru a modifica adresa o eticheta</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Crează o nouă adresă</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Nou</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copiază în notițe adresa selectată în prezent</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiază</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Î&amp;nchide</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Copiază Adresa</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Șterge adresa curentă selectata din listă</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exportă datele din tabul curent in fisier</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exportă</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Indică adresa de expediere a monedelor</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Indică adresa de a primi monedele</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>FlurboGUI</name>
    </context>
<context>
    <name>ClientModel</name>
    </context>
<context>
    <name>CoinControlDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    </context>
<context>
    <name>Intro</name>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    </context>
<context>
    <name>OverviewPage</name>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    </context>
<context>
    <name>SendCoinsEntry</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exportă</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exportă datele din tabul curent in fisier</translation>
    </message>
    </context>
<context>
    <name>flurbo-core</name>
    </context>
</TS>